#include "Constants.h"

const int Constants::NUM_CIRCLE = 10;
const int Constants::PAGE_SIZE = 70;
const int Constants::COEFFS = 10;
Constants::Constants()
{
}