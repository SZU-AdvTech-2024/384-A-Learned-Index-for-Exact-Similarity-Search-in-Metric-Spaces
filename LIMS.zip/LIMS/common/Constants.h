/*
* constants value
*
* author : ty_yan
*/

#ifndef CONSTANTS_H
#define CONSTANTS_H

class Constants
{
public:
    static const int NUM_CIRCLE;
    static const int PAGE_SIZE;
    static const int COEFFS;

    Constants();
};

#endif